﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Day30
{
    public partial class Studentdetails : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;

        List<StudentClass> studlist;
        List<Departmentclass> deptlist;
        public Studentdetails()
        {
            InitializeComponent();

            studlist = new List<StudentClass>();
            deptlist = new List<Departmentclass>();
        }

        DataTable getStudentsDetails()
        {
            dt = new DataTable("Students");

            dc = new DataColumn("RollNumber", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };
            dc = new DataColumn("FullName", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Subject", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Fees", typeof(float));
            dt.Columns.Add(dc);

            dc = new DataColumn("DeptId", typeof(int));
            dt.Columns.Add(dc);

            foreach(var ob in studlist)
            {
                //Add Row
                dr = dt.NewRow();
                dr[0] = ob.roll;
                dr[1] = ob.studentname;
                dr[2] = ob.suject;
                dr[3] = ob.fees;
                dr[4] = ob.deptid;
                dt.Rows.Add(dr);
            }
            

            return dt;
        }

        DataTable getDepartmentdetails()
        {
            dt = new DataTable("Department");

            dc = new DataColumn("deptid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("deptname", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("depthod", typeof(string));
            dt.Columns.Add(dc);

            foreach(var d in deptlist)
            {
                dr = dt.NewRow();
                dr[0] = d.deptid;
                dr[1] = d.deptname;
                dr[2] = d.hod;
                dt.Rows.Add(dr);
            }

            return dt;
        }
        private void Studentdetails_Load(object sender, EventArgs e)
        {
           
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtrollnum.Text = "";
            txtfname.Text = "";
            txtsubject.Text = "";
            txtfees.Text = "";
            txtdeptid.Text = "";
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            StudentClass ob = new StudentClass();
            ob.roll = int.Parse(txtrollnum.Text.ToString());
            ob.studentname = txtfname.Text.ToString();
            ob.suject = txtsubject.Text.ToString();
            ob.fees = float.Parse(txtfees.Text.ToString());
            ob.deptid = int.Parse(txtdeptid.Text.ToString());

            studlist.Add(ob);

            DataTable stu = getStudentsDetails();
            dataGridView1.DataSource = stu;
        }

        private void btndeptclear_Click(object sender, EventArgs e)
        {
            txtdeptid1.Text = "";
            txtdeptname.Text = "";
            txtdepthod.Text = "";
        }

        private void btndeptsubmit_Click(object sender, EventArgs e)
        {
            Departmentclass dp = new Departmentclass();
            dp.deptid =  int.Parse(txtdeptid1.Text.ToString());
            dp.deptname = txtdeptname.Text.ToString();
            dp.hod = txtdepthod.Text.ToString();

            deptlist.Add(dp);

            DataTable dept = getDepartmentdetails();
            dataGridView2.DataSource = dept;

        }
    }
}
