﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day30
{
    class StudentClass
    {
        public int roll, deptid;
        public float fees;
        public string studentname, suject;

        public void getData(int r,string fn,string sub,float fe,int dep)
        {
            roll = r;
            studentname = fn;
            suject = sub;
            fees = fe;
            deptid = dep;
        }
    }
}
