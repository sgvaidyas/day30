﻿namespace Day30
{
    partial class Studentdetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtrollnum = new System.Windows.Forms.TextBox();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.txtsubject = new System.Windows.Forms.TextBox();
            this.txtfees = new System.Windows.Forms.TextBox();
            this.txtdeptid = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.txtdepthod = new System.Windows.Forms.TextBox();
            this.txtdeptname = new System.Windows.Forms.TextBox();
            this.txtdeptid1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btndeptclear = new System.Windows.Forms.Button();
            this.btndeptsubmit = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 282);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(542, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "ROLL NO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "STUDENT NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "SUBJECT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "FEES";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 218);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "DEPARTMENT ID";
            // 
            // txtrollnum
            // 
            this.txtrollnum.Location = new System.Drawing.Point(211, 18);
            this.txtrollnum.Name = "txtrollnum";
            this.txtrollnum.Size = new System.Drawing.Size(170, 20);
            this.txtrollnum.TabIndex = 6;
            // 
            // txtfname
            // 
            this.txtfname.Location = new System.Drawing.Point(211, 72);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(170, 20);
            this.txtfname.TabIndex = 7;
            // 
            // txtsubject
            // 
            this.txtsubject.Location = new System.Drawing.Point(211, 121);
            this.txtsubject.Name = "txtsubject";
            this.txtsubject.Size = new System.Drawing.Size(170, 20);
            this.txtsubject.TabIndex = 8;
            // 
            // txtfees
            // 
            this.txtfees.Location = new System.Drawing.Point(211, 168);
            this.txtfees.Name = "txtfees";
            this.txtfees.Size = new System.Drawing.Size(170, 20);
            this.txtfees.TabIndex = 9;
            // 
            // txtdeptid
            // 
            this.txtdeptid.Location = new System.Drawing.Point(211, 211);
            this.txtdeptid.Name = "txtdeptid";
            this.txtdeptid.Size = new System.Drawing.Size(170, 20);
            this.txtdeptid.TabIndex = 10;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(211, 253);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 11;
            this.btnsubmit.Text = "SAVE";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(300, 253);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(75, 23);
            this.btnclear.TabIndex = 12;
            this.btnclear.Text = "CLEAR";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // txtdepthod
            // 
            this.txtdepthod.Location = new System.Drawing.Point(736, 156);
            this.txtdepthod.Name = "txtdepthod";
            this.txtdepthod.Size = new System.Drawing.Size(170, 20);
            this.txtdepthod.TabIndex = 18;
            // 
            // txtdeptname
            // 
            this.txtdeptname.Location = new System.Drawing.Point(736, 107);
            this.txtdeptname.Name = "txtdeptname";
            this.txtdeptname.Size = new System.Drawing.Size(170, 20);
            this.txtdeptname.TabIndex = 17;
            // 
            // txtdeptid1
            // 
            this.txtdeptid1.Location = new System.Drawing.Point(736, 53);
            this.txtdeptid1.Name = "txtdeptid1";
            this.txtdeptid1.Size = new System.Drawing.Size(170, 20);
            this.txtdeptid1.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(560, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "HOD";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(560, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "DEPARTMENT NAME";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(560, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "DEPARTMENT ID";
            // 
            // btndeptclear
            // 
            this.btndeptclear.Location = new System.Drawing.Point(825, 203);
            this.btndeptclear.Name = "btndeptclear";
            this.btndeptclear.Size = new System.Drawing.Size(75, 23);
            this.btndeptclear.TabIndex = 20;
            this.btndeptclear.Text = "CLEAR";
            this.btndeptclear.UseVisualStyleBackColor = true;
            this.btndeptclear.Click += new System.EventHandler(this.btndeptclear_Click);
            // 
            // btndeptsubmit
            // 
            this.btndeptsubmit.Location = new System.Drawing.Point(736, 203);
            this.btndeptsubmit.Name = "btndeptsubmit";
            this.btndeptsubmit.Size = new System.Drawing.Size(75, 23);
            this.btndeptsubmit.TabIndex = 19;
            this.btndeptsubmit.Text = "SAVE";
            this.btndeptsubmit.UseVisualStyleBackColor = true;
            this.btndeptsubmit.Click += new System.EventHandler(this.btndeptsubmit_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(598, 282);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(330, 150);
            this.dataGridView2.TabIndex = 21;
            // 
            // Studentdetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 450);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btndeptclear);
            this.Controls.Add(this.btndeptsubmit);
            this.Controls.Add(this.txtdepthod);
            this.Controls.Add(this.txtdeptname);
            this.Controls.Add(this.txtdeptid1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txtdeptid);
            this.Controls.Add(this.txtfees);
            this.Controls.Add(this.txtsubject);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.txtrollnum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Studentdetails";
            this.Text = "Studentdetails";
            this.Load += new System.EventHandler(this.Studentdetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtrollnum;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.TextBox txtsubject;
        private System.Windows.Forms.TextBox txtfees;
        private System.Windows.Forms.TextBox txtdeptid;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.TextBox txtdepthod;
        private System.Windows.Forms.TextBox txtdeptname;
        private System.Windows.Forms.TextBox txtdeptid1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btndeptclear;
        private System.Windows.Forms.Button btndeptsubmit;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}