﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Day30
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        public Form1()
        {
            InitializeComponent();
        }
        DataTable GetEmployeeDetails()
        {
            dt = new DataTable("Employee");

            dc = new DataColumn("Empid",typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("EmployeeName",typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Age", typeof(int));
            dt.Columns.Add(dc);

            dc = new DataColumn("Salary", typeof(float));
            dt.Columns.Add(dc);

            dr = dt.NewRow();
            dr[0] = 111;
            dr[1] = "Manjunath";
            dr[2] = 22;
            dr[3] = 40000;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["Empid"] = 112;
            dr["EmployeeName"] = "Althaf";
            dr["Age"] = 22;
            dr["Salary"] = 42000;
            dt.Rows.Add(dr);


            return dt;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable emp = GetEmployeeDetails();
            dataGridView1.DataSource = emp;
        }
    }
}
