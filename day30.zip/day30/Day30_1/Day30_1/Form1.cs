﻿using System;
using System.Data;
using Newtonsoft.Json;
using System.Windows.Forms;
using System.IO;

namespace Day30_1
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;

        DataSet ds;

        public Form1()
        {
            InitializeComponent();
        }
        DataTable getcoursedetails()
        {
            dt = new DataTable("Course");

            dc = new DataColumn("CID", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Coursename", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Deptid", typeof(int));
            dt.Columns.Add(dc);

            dr = dt.NewRow();
            dr[0] = 111;
            dr[1] = "Python";
            dr[2] = 222;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 112;
            dr[1] = "Acting";
            dr[2] = 223;
            dt.Rows.Add(dr);
            return dt;
        }


        DataTable getDeptdetails()
        {
            dt = new DataTable("Department");

            dc = new DataColumn("Deptid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Departmentname", typeof(string));
            dt.Columns.Add(dc);


            dr = dt.NewRow();
            dr[0] = 222;
            dr[1] = "CSE";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 223;
            dr[1] = "ARTS";
            dt.Rows.Add(dr);
            return dt;
        }

        DataSet createDataset()
        {
            DataTable course = getcoursedetails();
            DataTable dep = getDeptdetails();

            ds = new DataSet("Mydataset");
            ds.Tables.Add(course);
            ds.Tables.Add(dep);

            //DataColumn colPrimarykey = ds.Tables[1].Columns[0];
            DataColumn colPrimarykey = ds.Tables["Department"].Columns["Deptid"];
            //DataColumn colForeignkey = ds.Tables[0].Columns[2];
            DataColumn colForeignkey = ds.Tables["Course"].Columns["Deptid"];

            DataRelation depcourserel = new DataRelation("CourseandDep" , colPrimarykey,colForeignkey);
            ds.Relations.Add(depcourserel);
            
            return ds;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
           
            DataSet dt1= createDataset();
            dataGridView1.DataSource = dt1.Tables[0];
            dataGridView2.DataSource = dt1.Tables[1];
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable c = getcoursedetails();
            c.WriteXml("E:\\myxml.xml");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable d = getDeptdetails();
            string myjson = JsonConvert.SerializeObject(d);
            StreamWriter sw = File.CreateText(@"D:\jsonobjectfile.json");
            sw.WriteLine(myjson);
            sw.Close();
        }
    }
}
